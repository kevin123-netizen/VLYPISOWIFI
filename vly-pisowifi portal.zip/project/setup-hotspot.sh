#!/bin/bash
# ============================================================
# VLY PisoWiFi - Raspberry Pi Hotspot Setup Script
# ============================================================
# This script turns your Raspberry Pi into a coin-operated WiFi
# hotspot with a captive portal at 10.0.0.1
#
# Run on a fresh Raspberry Pi OS (Bookworm/Bullseye) install:
#   sudo bash setup-hotspot.sh
# ============================================================

set -e

PORTAL_DIR="/opt/vly-pisowifi"
NODE_VERSION="20"

echo "========================================"
echo "  VLY PisoWiFi - Hotspot Setup"
echo "========================================"

# Check root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root: sudo bash setup-hotspot.sh"
  exit 1
fi

echo "[1/8] Updating system packages..."
apt-get update -qq
apt-get upgrade -y -qq

echo "[2/8] Installing required packages..."
apt-get install -y -qq \
  hostapd dnsmasq iptables-persistent nginx \
  git curl wget unzip

echo "[3/8] Installing Node.js ${NODE_VERSION}..."
if ! command -v node &> /dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
  apt-get install -y -qq nodejs
fi
echo "  Node.js version: $(node -v)"

echo "[4/8] Setting up static IP 10.0.0.1..."
cat > /etc/dhcpcd.conf << 'DHCPCD_EOF'

# VLY PisoWiFi Hotspot Configuration
interface wlan0
    static ip_address=10.0.0.1/24
    nohook wpa_supplicant
DHCPCD_EOF

echo "[5/8] Configuring DHCP server (dnsmasq)..."
cat > /etc/dnsmasq.conf << 'DNSMASQ_EOF'
# VLY PisoWiFi DHCP Configuration
interface=wlan0
  dhcp-range=10.0.0.10,10.0.0.50,255.255.255.0,24h
  dhcp-option=3,10.0.0.1
  dhcp-option=6,10.0.0.1
  address=/#/10.0.0.1
DNSMASQ_EOF

echo "[6/8] Configuring WiFi Access Point (hostapd)..."
cat > /etc/hostapd/hostapd.conf << 'HOSTAPD_EOF'
# VLY PisoWiFi Access Point Configuration
interface=wlan0
driver=nl80211
ssid=VLY-PisoWiFi
hw_mode=g
channel=6
wmm_enabled=0
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=vly12345
wpa_key_mgmt=WPA-PSK
rsn_pairwise=CCMP
HOSTAPD_EOF

# Tell hostapd where its config is
cat > /etc/default/hostapd << 'HOSTAPD_DEFAULT_EOF'
DAEMON_CONF="/etc/hostapd/hostapd.conf"
HOSTAPD_DEFAULT_EOF

echo "[7/8] Setting up captive portal firewall rules..."
# Enable IP forwarding
echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
sysctl -p

# NAT routing (so connected clients can reach internet if you have eth0)
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
iptables -A FORWARD -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i wlan0 -o eth0 -j ACCEPT

# Captive portal: redirect all HTTP traffic to 10.0.0.1
iptables -t nat -A PREROUTING -i wlan0 -p tcp --dport 80 -j DNAT --to-destination 10.0.0.1:80
iptables -t nat -A PREROUTING -i wlan0 -p tcp --dport 443 -j DNAT --to-destination 10.0.0.1:80

# Save firewall rules
netfilter-persistent save

echo "[8/8] Deploying portal application..."
mkdir -p ${PORTAL_DIR}

# Copy project files (if this script is in the project directory)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "${SCRIPT_DIR}/package.json" ]; then
  echo "  Copying project files from ${SCRIPT_DIR}..."
  cp -r ${SCRIPT_DIR}/* ${PORTAL_DIR}/
  cp -r ${SCRIPT_DIR}/.env ${PORTAL_DIR}/ 2>/dev/null || true
else
  echo "  Downloading project files..."
  # If no local files, clone or copy from USB
  echo "  ERROR: Please place this script inside the project folder and re-run."
  echo "  Or copy your project files to ${PORTAL_DIR} manually."
  exit 1
fi

cd ${PORTAL_DIR}
echo "  Installing npm dependencies..."
npm install --production

echo "  Building production bundle..."
npm run build

# Copy pre-built ZIP for download
if [ -f "${PORTAL_DIR}/public/vly-pisowifi.zip" ]; then
  cp "${PORTAL_DIR}/public/vly-pisowifi.zip" "${PORTAL_DIR}/dist/vly-pisowifi.zip"
fi

echo "  Configuring nginx to serve the portal on port 80..."
cat > /etc/nginx/sites-available/vly-pisowifi << 'NGINX_EOF'
server {
    listen 80 default_server;
    listen [::]:80 default_server;

    root /opt/vly-pisowifi/dist;
    index index.html;

    server_name _;

    # Captive portal detection endpoints (Apple, Android, Windows)
    location /hotspot-detect.html { return 302 http://10.0.0.1/; }
    location /generate_204 { return 302 http://10.0.0.1/; }
    location /connecttest.txt { return 302 http://10.0.0.1/; }
    location /ncsi.txt { return 302 http://10.0.0.1/; }
    location /library/test/success.html { return 302 http://10.0.0.1/; }

    # Serve the React app (SPA fallback for /admin and all routes)
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Serve the downloadable ZIP
    location /vly-pisowifi.zip {
        alias /opt/vly-pisowifi/dist/vly-pisowifi.zip;
        default_type application/zip;
        add_header Content-Disposition "attachment; filename=vly-pisowifi.zip";
    }
}
NGINX_EOF

ln -sf /etc/nginx/sites-available/vly-pisowifi /etc/nginx/sites-enabled/vly-pisowifi
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx

# Create systemd service for the portal (fallback if not using nginx)
cat > /etc/systemd/system/vly-pisowifi.service << 'SYSTEMD_EOF'
[Unit]
Description=VLY PisoWiFi Portal
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/vly-pisowifi
ExecStart=/usr/bin/npm run preview -- --host 10.0.0.1 --port 8080
Restart=always
RestartSec=3
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
SYSTEMD_EOF

systemctl daemon-reload

# Enable and start services
systemctl unmask hostapd
systemctl enable hostapd
systemctl enable dnsmasq
systemctl enable nginx
systemctl enable vly-pisowifi

systemctl restart dnsmasq
systemctl restart hostapd
systemctl restart nginx

echo ""
echo "========================================"
echo "  SETUP COMPLETE!"
echo "========================================"
echo ""
echo "  WiFi Network:  VLY-PisoWiFi"
echo "  WiFi Password:  vly12345"
echo "  Portal Address:  10.0.0.1"
echo "  Admin Panel:    http://10.0.0.1/admin"
echo ""
echo "  To change WiFi name/password:"
echo "    sudo nano /etc/hostapd/hostapd.conf"
echo ""
echo "  To change portal settings:"
echo "    Open admin panel in browser"
echo ""
echo "  REBOOT the Raspberry Pi now:"
echo "    sudo reboot"
echo ""
echo "  After reboot, connect any device to"
echo "  'VLY-PisoWiFi' WiFi and open a browser"
echo "  - the portal will appear automatically!"
echo ""

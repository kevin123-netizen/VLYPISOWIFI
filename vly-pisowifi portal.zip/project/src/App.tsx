import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import CustomerPortal from '@/components/CustomerPortal';
import AdminLogin from '@/components/AdminLogin';
import AdminPanel from '@/components/AdminPanel';
import { Download } from 'lucide-react';

type Route = 'portal' | 'admin';

function getRouteFromPath(): Route {
  return window.location.pathname.replace(/\/$/, '') === '/admin' ? 'admin' : 'portal';
}

export default function App() {
  const [route, setRoute] = useState<Route>(getRouteFromPath);
  const [adminAuthed, setAdminAuthed] = useState(false);

  useEffect(() => {
    const onPopState = () => setRoute(getRouteFromPath());
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    if (route === 'admin') {
      supabase.auth.getSession().then(({ data }) => {
        setAdminAuthed(!!data.session);
      });
    }
  }, [route]);

  useEffect(() => {
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      (async () => {
        setAdminAuthed(!!session);
      })();
    });
    return () => authListener.subscription.unsubscribe();
  }, []);

  const navigateTo = (path: string) => {
    window.history.pushState({}, '', path);
    setRoute(getRouteFromPath());
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setAdminAuthed(false);
    navigateTo('/');
  };

  if (route === 'admin') {
    if (adminAuthed) {
      return <AdminPanel onLogout={handleLogout} />;
    }
    return <AdminLogin onLogin={() => setAdminAuthed(true)} onBack={() => navigateTo('/')} />;
  }

  return (
    <div className="relative">
      <CustomerPortal />
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 items-end">
        <a
          href="/vly-pisowifi.zip"
          download
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-cyan-500/90 backdrop-blur-sm border border-cyan-400/50 text-white text-xs font-medium hover:bg-cyan-400 transition-all"
        >
          <Download className="w-3.5 h-3.5" />
          Download Project
        </a>
        <button
          onClick={() => navigateTo('/admin')}
          className="px-3 py-2 rounded-lg bg-slate-800/80 backdrop-blur-sm border border-slate-700 text-slate-400 text-xs hover:text-white hover:border-slate-600 transition-all"
        >
          Admin
        </button>
      </div>
    </div>
  );
}

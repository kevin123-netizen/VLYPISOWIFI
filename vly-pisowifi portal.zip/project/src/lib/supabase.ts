import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Rate = {
  id: string;
  coin_value: number;
  time_seconds: number;
  label: string;
  is_active: boolean;
  created_at: string;
};

export type Voucher = {
  id: string;
  code: string;
  time_seconds: number;
  is_used: boolean;
  used_at: string | null;
  created_at: string;
};

export type Session = {
  id: string;
  device_id: string;
  time_remaining: number;
  expires_at: string;
  is_active: boolean;
  created_at: string;
};

export type Transaction = {
  id: string;
  type: 'coin' | 'voucher';
  coin_value: number | null;
  voucher_code: string | null;
  time_seconds: number;
  device_id: string | null;
  created_at: string;
};

export type AdminSetting = {
  id: string;
  key: string;
  value: string;
  updated_at: string;
};

export function getDeviceId(): string {
  let id = localStorage.getItem('pisowifi_device_id');
  if (!id) {
    id = 'dev_' + Math.random().toString(36).substring(2, 12) + Date.now().toString(36);
    localStorage.setItem('pisowifi_device_id', id);
  }
  return id;
}

export function formatTime(seconds: number): string {
  if (seconds <= 0) return '0s';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export function formatTimeShort(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

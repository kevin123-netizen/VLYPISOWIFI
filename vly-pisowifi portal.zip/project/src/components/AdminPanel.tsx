import { useState, useEffect, useCallback } from 'react';
import { supabase, type Rate, type Voucher, type Transaction, formatTimeShort } from '@/lib/supabase';
import { Wifi, LogOut, LayoutDashboard, Coins, Ticket, Receipt, Settings, Plus, Trash2, Loader2, TrendingUp, Clock, Users, ArrowLeft, Copy, Check } from 'lucide-react';

type AdminView = 'dashboard' | 'rates' | 'vouchers' | 'transactions' | 'settings';

type TimeInput = { hours: number; minutes: number; seconds: number };

function timeInputToSeconds(t: TimeInput): number {
  return t.hours * 3600 + t.minutes * 60 + t.seconds;
}

function secondsToTimeInput(total: number): TimeInput {
  return {
    hours: Math.floor(total / 3600),
    minutes: Math.floor((total % 3600) / 60),
    seconds: total % 60,
  };
}

function formatTimeLabel(t: TimeInput): string {
  const parts: string[] = [];
  if (t.hours > 0) parts.push(`${t.hours}h`);
  if (t.minutes > 0) parts.push(`${t.minutes}m`);
  if (t.seconds > 0) parts.push(`${t.seconds}s`);
  return parts.length > 0 ? parts.join(' ') : '0s';
}

const TIME_PRESETS: { label: string; value: TimeInput }[] = [
  { label: '30 Min', value: { hours: 0, minutes: 30, seconds: 0 } },
  { label: '1 Hour', value: { hours: 1, minutes: 0, seconds: 0 } },
  { label: '3 Hours', value: { hours: 3, minutes: 0, seconds: 0 } },
  { label: '6 Hours', value: { hours: 6, minutes: 0, seconds: 0 } },
  { label: '12 Hours', value: { hours: 12, minutes: 0, seconds: 0 } },
  { label: '1 Day', value: { hours: 24, minutes: 0, seconds: 0 } },
  { label: '3 Days', value: { hours: 72, minutes: 0, seconds: 0 } },
  { label: '7 Days', value: { hours: 168, minutes: 0, seconds: 0 } },
];

export default function AdminPanel({ onLogout }: { onLogout: () => void }) {
  const [view, setView] = useState<AdminView>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems: { id: AdminView; label: string; icon: typeof LayoutDashboard }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'rates', label: 'Time Rates', icon: Coins },
    { id: 'vouchers', label: 'Vouchers', icon: Ticket },
    { id: 'transactions', label: 'Transactions', icon: Receipt },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-950 flex">
      <aside className={`fixed md:static inset-y-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 flex flex-col transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        <div className="px-6 py-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Wifi className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-sm">VLY PisoWiFi</h1>
              <p className="text-slate-500 text-xs">Admin Panel</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button key={item.id} onClick={() => { setView(item.id); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${view === item.id ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}>
                <Icon className="w-5 h-5" />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="px-3 py-4 border-t border-slate-800 space-y-1">
          <button onClick={() => { window.history.pushState({}, '', '/'); window.dispatchEvent(new PopStateEvent('popstate')); }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-400 hover:text-white hover:bg-slate-800 transition-all">
            <ArrowLeft className="w-5 h-5" />
            Back to Portal
          </button>
          <button onClick={onLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all">
            <LogOut className="w-5 h-5" />
            Sign Out
          </button>
        </div>
      </aside>

      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={() => setSidebarOpen(false)} />}

      <div className="flex-1 flex flex-col min-w-0">
        <div className="md:hidden flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800">
          <button onClick={() => setSidebarOpen(true)} className="text-slate-400"><LayoutDashboard className="w-6 h-6" /></button>
          <span className="text-white font-semibold text-sm">Admin Panel</span>
          <div className="w-6" />
        </div>
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {view === 'dashboard' && <DashboardView />}
          {view === 'rates' && <RatesView />}
          {view === 'vouchers' && <VouchersView />}
          {view === 'transactions' && <TransactionsView />}
          {view === 'settings' && <SettingsView />}
        </main>
      </div>
    </div>
  );
}

function DashboardView() {
  const [stats, setStats] = useState({ totalCoins: 0, totalVouchers: 0, totalSeconds: 0, activeSessions: 0, todayCoins: 0, todaySeconds: 0 });
  const [recentTx, setRecentTx] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const [txRes, sessionRes] = await Promise.all([
        supabase.from('transactions').select('*').order('created_at', { ascending: false }).limit(10),
        supabase.from('sessions').select('*').eq('is_active', true),
      ]);
      const txs = txRes.data || [];
      setRecentTx(txs);
      const today = new Date(); today.setHours(0, 0, 0, 0);
      const todayTxs = txs.filter((t) => new Date(t.created_at) >= today);
      setStats({
        totalCoins: txs.filter((t) => t.type === 'coin').reduce((sum, t) => sum + (t.coin_value || 0), 0),
        totalVouchers: txs.filter((t) => t.type === 'voucher').length,
        totalSeconds: txs.reduce((sum, t) => sum + t.time_seconds, 0),
        activeSessions: (sessionRes.data || []).filter((s) => new Date(s.expires_at) > new Date()).length,
        todayCoins: todayTxs.filter((t) => t.type === 'coin').reduce((sum, t) => sum + (t.coin_value || 0), 0),
        todaySeconds: todayTxs.reduce((sum, t) => sum + t.time_seconds, 0),
      });
      setLoading(false);
    };
    load();
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 text-cyan-400 animate-spin" /></div>;

  const cards = [
    { label: 'Total Coins Collected', value: stats.totalCoins, icon: Coins, color: 'from-amber-400 to-amber-600', sub: `${stats.todayCoins} today` },
    { label: 'Total Time Sold', value: formatTimeShort(stats.totalSeconds), icon: Clock, color: 'from-cyan-400 to-blue-600', sub: `${formatTimeShort(stats.todaySeconds)} today` },
    { label: 'Vouchers Redeemed', value: stats.totalVouchers, icon: Ticket, color: 'from-purple-400 to-purple-600', sub: '' },
    { label: 'Active Sessions', value: stats.activeSessions, icon: Users, color: 'from-emerald-400 to-emerald-600', sub: '' },
  ];

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold text-white mb-1">Dashboard</h2><p className="text-slate-500 text-sm">Overview of your PisoWiFi operations</p></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="bg-slate-900 rounded-2xl border border-slate-800 p-5 hover:border-slate-700 transition-colors">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center`}><Icon className="w-5 h-5 text-white" /></div>
                {card.sub && <span className="text-xs text-slate-500">{card.sub}</span>}
              </div>
              <p className="text-2xl font-bold text-white">{card.value}</p>
              <p className="text-xs text-slate-500 mt-1">{card.label}</p>
            </div>
          );
        })}
      </div>
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5">
        <div className="flex items-center gap-2 mb-4"><TrendingUp className="w-5 h-5 text-cyan-400" /><h3 className="text-white font-semibold text-sm">Recent Transactions</h3></div>
        {recentTx.length === 0 ? <p className="text-slate-500 text-sm text-center py-8">No transactions yet.</p> : (
          <div className="space-y-2">
            {recentTx.map((tx) => (
              <div key={tx.id} className="flex items-center justify-between py-2.5 border-b border-slate-800 last:border-0">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${tx.type === 'coin' ? 'bg-amber-500/10' : 'bg-purple-500/10'}`}>
                    {tx.type === 'coin' ? <Coins className="w-4 h-4 text-amber-400" /> : <Ticket className="w-4 h-4 text-purple-400" />}
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium">{tx.type === 'coin' ? `${tx.coin_value} coin${tx.coin_value === 1 ? '' : 's'}` : `Voucher: ${tx.voucher_code}`}</p>
                    <p className="text-slate-500 text-xs">{new Date(tx.created_at).toLocaleString()}</p>
                  </div>
                </div>
                <span className="text-cyan-400 text-sm font-mono font-semibold">+{formatTimeShort(tx.time_seconds)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function TimePicker({ value, onChange, label }: { value: TimeInput; onChange: (t: TimeInput) => void; label?: string }) {
  return (
    <div>
      {label && <label className="text-xs text-slate-500 mb-1 block">{label}</label>}
      <div className="flex items-center gap-2">
        <div className="flex-1">
          <input type="number" min={0} max={999} value={value.hours}
            onChange={(e) => onChange({ ...value, hours: parseInt(e.target.value) || 0 })}
            className="w-full px-2 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm text-center focus:outline-none focus:border-cyan-400" />
          <p className="text-[10px] text-slate-600 text-center mt-1">Hours</p>
        </div>
        <div className="flex-1">
          <input type="number" min={0} max={59} value={value.minutes}
            onChange={(e) => onChange({ ...value, minutes: parseInt(e.target.value) || 0 })}
            className="w-full px-2 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm text-center focus:outline-none focus:border-cyan-400" />
          <p className="text-[10px] text-slate-600 text-center mt-1">Min</p>
        </div>
        <div className="flex-1">
          <input type="number" min={0} max={59} value={value.seconds}
            onChange={(e) => onChange({ ...value, seconds: parseInt(e.target.value) || 0 })}
            className="w-full px-2 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm text-center focus:outline-none focus:border-cyan-400" />
          <p className="text-[10px] text-slate-600 text-center mt-1">Sec</p>
        </div>
      </div>
    </div>
  );
}

function RatesView() {
  const [rates, setRates] = useState<Rate[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [newRate, setNewRate] = useState<{ coin_value: number; time: TimeInput; label: string }>({
    coin_value: 1, time: { hours: 1, minutes: 0, seconds: 0 }, label: '',
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTime, setEditTime] = useState<TimeInput>({ hours: 0, minutes: 0, seconds: 0 });

  const fetchRates = useCallback(async () => {
    const { data } = await supabase.from('rates').select('*').order('coin_value');
    setRates(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchRates(); }, [fetchRates]);

  const handleAdd = async () => {
    const totalSeconds = timeInputToSeconds(newRate.time);
    if (totalSeconds <= 0) return;
    setAdding(true);
    await supabase.from('rates').insert({
      coin_value: newRate.coin_value,
      time_seconds: totalSeconds,
      label: newRate.label || formatTimeLabel(newRate.time),
      is_active: true,
    });
    setNewRate({ coin_value: 1, time: { hours: 1, minutes: 0, seconds: 0 }, label: '' });
    setAdding(false);
    fetchRates();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('rates').delete().eq('id', id);
    fetchRates();
  };

  const handleToggle = async (rate: Rate) => {
    await supabase.from('rates').update({ is_active: !rate.is_active }).eq('id', rate.id);
    fetchRates();
  };

  const startEdit = (rate: Rate) => {
    setEditingId(rate.id);
    setEditTime(secondsToTimeInput(rate.time_seconds));
  };

  const saveEdit = async (id: string) => {
    const totalSeconds = timeInputToSeconds(editTime);
    if (totalSeconds <= 0) return;
    await supabase.from('rates').update({
      time_seconds: totalSeconds,
      label: formatTimeLabel(editTime),
    }).eq('id', id);
    setEditingId(null);
    fetchRates();
  };

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 text-cyan-400 animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold text-white mb-1">Time Rates</h2><p className="text-slate-500 text-sm">Configure how much internet time each coin gives</p></div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5">
        <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2"><Plus className="w-4 h-4 text-cyan-400" />Add New Rate</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="text-xs text-slate-500 mb-1 block">Coins Required</label>
            <input type="number" min={1} value={newRate.coin_value}
              onChange={(e) => setNewRate({ ...newRate, coin_value: parseInt(e.target.value) || 1 })}
              className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-400" />
          </div>
          <div className="sm:col-span-1">
            <TimePicker label="Time Granted" value={newRate.time} onChange={(t) => setNewRate({ ...newRate, time: t })} />
          </div>
          <div className="flex flex-col">
            <label className="text-xs text-slate-500 mb-1 block">Custom Label (optional)</label>
            <input type="text" placeholder="e.g. 1 Hour" value={newRate.label}
              onChange={(e) => setNewRate({ ...newRate, label: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm placeholder:text-slate-600 focus:outline-none focus:border-cyan-400" />
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {TIME_PRESETS.slice(0, 6).map((preset) => (
            <button key={preset.label} onClick={() => setNewRate({ ...newRate, time: preset.value })}
              className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-800 text-slate-400 hover:bg-cyan-500/10 hover:text-cyan-400 border border-slate-700 hover:border-cyan-500/30 transition-all">
              {preset.label}
            </button>
          ))}
        </div>
        <button onClick={handleAdd} disabled={adding}
          className="mt-4 px-5 py-2.5 rounded-lg bg-cyan-500 text-white font-semibold text-sm hover:bg-cyan-400 transition-colors flex items-center gap-2 disabled:opacity-50">
          {adding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
          Add Rate
        </button>
      </div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
        {rates.length === 0 ? <p className="text-slate-500 text-sm text-center py-12">No rates configured yet. Add one above to get started.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Coins</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Time Granted</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Label</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Status</th>
                  <th className="text-right text-xs text-slate-500 font-medium px-5 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rates.map((rate) => (
                  <tr key={rate.id} className="border-b border-slate-800 last:border-0 hover:bg-slate-800/50 transition-colors">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-md">
                          <span className="text-xs font-bold text-amber-950">{rate.coin_value}</span>
                        </div>
                        <span className="text-white text-sm font-medium">{rate.coin_value} {rate.coin_value === 1 ? 'coin' : 'coins'}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      {editingId === rate.id ? (
                        <div className="w-48">
                          <TimePicker value={editTime} onChange={setEditTime} />
                        </div>
                      ) : (
                        <span className="text-cyan-400 font-mono text-sm font-semibold">{formatTimeShort(rate.time_seconds)}</span>
                      )}
                    </td>
                    <td className="px-5 py-3 text-slate-300 text-sm">{rate.label || '-'}</td>
                    <td className="px-5 py-3">
                      <button onClick={() => handleToggle(rate)}
                        className={`px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${rate.is_active ? 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20' : 'bg-slate-700 text-slate-400 hover:bg-slate-600'}`}>
                        {rate.is_active ? 'Active' : 'Inactive'}
                      </button>
                    </td>
                    <td className="px-5 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {editingId === rate.id ? (
                          <>
                            <button onClick={() => saveEdit(rate.id)} className="text-emerald-400 hover:text-emerald-300"><Check className="w-4 h-4" /></button>
                            <button onClick={() => setEditingId(null)} className="text-slate-500 hover:text-slate-300"><span className="text-xs">Cancel</span></button>
                          </>
                        ) : (
                          <>
                            <button onClick={() => startEdit(rate)} className="text-slate-500 hover:text-cyan-400 text-xs">Edit</button>
                            <button onClick={() => handleDelete(rate.id)} className="text-slate-500 hover:text-red-400 transition-colors"><Trash2 className="w-4 h-4" /></button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function VouchersView() {
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [genConfig, setGenConfig] = useState<{ count: number; time: TimeInput; prefix: string }>({
    count: 1, time: { hours: 1, minutes: 0, seconds: 0 }, prefix: 'VLY',
  });
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'available' | 'used'>('all');

  const fetchVouchers = useCallback(async () => {
    const { data } = await supabase.from('vouchers').select('*').order('created_at', { ascending: false }).limit(200);
    setVouchers(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchVouchers(); }, [fetchVouchers]);

  const generateCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = genConfig.prefix;
    for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
    return code;
  };

  const handleGenerate = async () => {
    const totalSeconds = timeInputToSeconds(genConfig.time);
    if (totalSeconds <= 0) return;
    setGenerating(true);
    const newVouchers = Array.from({ length: genConfig.count }, () => ({
      code: generateCode(), time_seconds: totalSeconds, is_used: false,
    }));
    await supabase.from('vouchers').insert(newVouchers);
    setGenerating(false);
    fetchVouchers();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('vouchers').delete().eq('id', id);
    fetchVouchers();
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 1500);
  };

  const filtered = filter === 'all' ? vouchers : filter === 'available' ? vouchers.filter((v) => !v.is_used) : vouchers.filter((v) => v.is_used);

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 text-cyan-400 animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold text-white mb-1">Vouchers</h2><p className="text-slate-500 text-sm">Generate voucher codes that customers can redeem for internet time</p></div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5">
        <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2"><Plus className="w-4 h-4 text-cyan-400" />Generate Vouchers</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="text-xs text-slate-500 mb-1 block">How Many Vouchers</label>
            <input type="number" min={1} max={500} value={genConfig.count}
              onChange={(e) => setGenConfig({ ...genConfig, count: parseInt(e.target.value) || 1 })}
              className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-400" />
          </div>
          <div>
            <TimePicker label="Time Per Voucher" value={genConfig.time} onChange={(t) => setGenConfig({ ...genConfig, time: t })} />
          </div>
          <div>
            <label className="text-xs text-slate-500 mb-1 block">Code Prefix</label>
            <input type="text" maxLength={4} value={genConfig.prefix}
              onChange={(e) => setGenConfig({ ...genConfig, prefix: e.target.value.toUpperCase() })}
              className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm font-mono focus:outline-none focus:border-cyan-400" />
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {TIME_PRESETS.map((preset) => (
            <button key={preset.label} onClick={() => setGenConfig({ ...genConfig, time: preset.value })}
              className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-800 text-slate-400 hover:bg-purple-500/10 hover:text-purple-400 border border-slate-700 hover:border-purple-500/30 transition-all">
              {preset.label}
            </button>
          ))}
        </div>
        <button onClick={handleGenerate} disabled={generating}
          className="mt-4 px-5 py-2.5 rounded-lg bg-gradient-to-r from-purple-500 to-purple-600 text-white font-semibold text-sm hover:from-purple-400 hover:to-purple-500 transition-all flex items-center gap-2 disabled:opacity-50">
          {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
          Generate {genConfig.count > 1 ? `${genConfig.count} Vouchers` : 'Voucher'}
        </button>
      </div>

      <div className="flex items-center justify-between flex-wrap gap-3">
        <h3 className="text-white font-semibold text-sm">All Vouchers ({vouchers.length})</h3>
        <div className="flex gap-2">
          {(['all', 'available', 'used'] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${filter === f ? 'bg-cyan-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
        {filtered.length === 0 ? <p className="text-slate-500 text-sm text-center py-12">No vouchers found.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Code</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Time</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Status</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Created</th>
                  <th className="text-right text-xs text-slate-500 font-medium px-5 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((v) => (
                  <tr key={v.id} className="border-b border-slate-800 last:border-0 hover:bg-slate-800/50 transition-colors">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-white text-sm font-semibold">{v.code}</span>
                        <button onClick={() => handleCopy(v.code)} className="text-slate-600 hover:text-cyan-400 transition-colors">
                          {copiedCode === v.code ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-cyan-400 font-mono text-sm">{formatTimeShort(v.time_seconds)}</td>
                    <td className="px-5 py-3">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${v.is_used ? 'bg-red-500/10 text-red-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
                        {v.is_used ? 'Used' : 'Available'}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-slate-500 text-xs">{new Date(v.created_at).toLocaleDateString()}</td>
                    <td className="px-5 py-3 text-right">
                      {!v.is_used && <button onClick={() => handleDelete(v.id)} className="text-slate-500 hover:text-red-400 transition-colors"><Trash2 className="w-4 h-4" /></button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function TransactionsView() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'coin' | 'voucher'>('all');

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from('transactions').select('*').order('created_at', { ascending: false }).limit(200);
      setTransactions(data || []);
      setLoading(false);
    };
    load();
  }, []);

  const filtered = filter === 'all' ? transactions : transactions.filter((t) => t.type === filter);

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 text-cyan-400 animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h2 className="text-2xl font-bold text-white mb-1">Transactions</h2><p className="text-slate-500 text-sm">Complete audit log of all activity</p></div>
        <div className="flex gap-2">
          {(['all', 'coin', 'voucher'] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${filter === f ? 'bg-cyan-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
              {f}
            </button>
          ))}
        </div>
      </div>
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
        {filtered.length === 0 ? <p className="text-slate-500 text-sm text-center py-12">No transactions found.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Type</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Details</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Time Granted</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Device</th>
                  <th className="text-left text-xs text-slate-500 font-medium px-5 py-3">Date & Time</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((tx) => (
                  <tr key={tx.id} className="border-b border-slate-800 last:border-0 hover:bg-slate-800/50 transition-colors">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${tx.type === 'coin' ? 'bg-amber-500/10' : 'bg-purple-500/10'}`}>
                          {tx.type === 'coin' ? <Coins className="w-4 h-4 text-amber-400" /> : <Ticket className="w-4 h-4 text-purple-400" />}
                        </div>
                        <span className="text-white text-sm capitalize">{tx.type}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-slate-300 text-sm">{tx.type === 'coin' ? `${tx.coin_value} coin${tx.coin_value === 1 ? '' : 's'}` : tx.voucher_code || '-'}</td>
                    <td className="px-5 py-3 text-cyan-400 font-mono text-sm font-semibold">{formatTimeShort(tx.time_seconds)}</td>
                    <td className="px-5 py-3 text-slate-500 text-xs font-mono">{tx.device_id ? tx.device_id.substring(0, 12) + '...' : '-'}</td>
                    <td className="px-5 py-3 text-slate-500 text-xs">{new Date(tx.created_at).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function SettingsView() {
  const [settings, setSettings] = useState({ portal_name: '', portal_subtitle: '' });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from('admin_settings').select('key, value');
      if (data) {
        const map: Record<string, string> = {};
        data.forEach((s) => { map[s.key] = s.value; });
        setSettings({ portal_name: map['portal_name'] || 'VLY PisoWiFi', portal_subtitle: map['portal_subtitle'] || 'Insert Coin to Start' });
      }
    };
    load();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await Promise.all([
      supabase.from('admin_settings').upsert({ key: 'portal_name', value: settings.portal_name, updated_at: new Date().toISOString() }, { onConflict: 'key' }),
      supabase.from('admin_settings').upsert({ key: 'portal_subtitle', value: settings.portal_subtitle, updated_at: new Date().toISOString() }, { onConflict: 'key' }),
    ]);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold text-white mb-1">Settings</h2><p className="text-slate-500 text-sm">Configure your portal appearance</p></div>
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 max-w-lg">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-slate-500 mb-1 block">Portal Name</label>
            <input type="text" value={settings.portal_name} onChange={(e) => setSettings({ ...settings, portal_name: e.target.value })}
              className="w-full px-3 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-slate-500 mb-1 block">Portal Subtitle</label>
            <input type="text" value={settings.portal_subtitle} onChange={(e) => setSettings({ ...settings, portal_subtitle: e.target.value })}
              className="w-full px-3 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-400" />
          </div>
          <button onClick={handleSave} disabled={saving}
            className="px-5 py-2.5 rounded-lg bg-cyan-500 text-white font-semibold text-sm hover:bg-cyan-400 transition-colors flex items-center gap-2 disabled:opacity-50">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            {saved ? 'Saved!' : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
}

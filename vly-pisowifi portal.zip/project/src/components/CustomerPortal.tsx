import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase, type Rate, type Session, formatTimeShort, getDeviceId } from '@/lib/supabase';
import { Wifi, Coins, Ticket, Clock, Zap, Info, Loader2, Check } from 'lucide-react';

type PortalSettings = {
  name: string;
  subtitle: string;
};

export default function CustomerPortal() {
  const [rates, setRates] = useState<Rate[]>([]);
  const [settings, setSettings] = useState<PortalSettings>({ name: 'VLY PisoWiFi', subtitle: 'Insert Coin to Start' });
  const [session, setSession] = useState<Session | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [voucherCode, setVoucherCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [selectedRate, setSelectedRate] = useState<number | null>(null);
  const deviceId = useRef(getDeviceId()).current;
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchInitialData = useCallback(async () => {
    const [ratesRes, settingsRes, sessionRes] = await Promise.all([
      supabase.from('rates').select('*').eq('is_active', true).order('coin_value'),
      supabase.from('admin_settings').select('key, value'),
      supabase.from('sessions').select('*').eq('device_id', deviceId).eq('is_active', true).order('created_at', { ascending: false }).limit(1).maybeSingle(),
    ]);

    if (ratesRes.data) setRates(ratesRes.data);
    if (settingsRes.data) {
      const map: Record<string, string> = {};
      settingsRes.data.forEach((s) => { map[s.key] = s.value; });
      setSettings({
        name: map['portal_name'] || 'VLY PisoWiFi',
        subtitle: map['portal_subtitle'] || 'Insert Coin to Start',
      });
    }
    if (sessionRes.data) {
      setSession(sessionRes.data);
      const remaining = Math.max(0, Math.floor((new Date(sessionRes.data.expires_at).getTime() - Date.now()) / 1000));
      setTimeRemaining(remaining);
    }
  }, [deviceId]);

  useEffect(() => {
    fetchInitialData();
  }, [fetchInitialData]);

  useEffect(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (timeRemaining > 0) {
      timerRef.current = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            if (timerRef.current) clearInterval(timerRef.current);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timeRemaining > 0]);

  const handleInsertCoin = async (rate: Rate) => {
    setLoading(true);
    setMessage(null);
    try {
      const now = Date.now();
      let newExpiresAt: string;
      let newTimeRemaining: number;

      if (session) {
        const currentExpiry = new Date(session.expires_at).getTime();
        const base = Math.max(currentExpiry, now);
        newTimeRemaining = Math.floor((base - now) / 1000) + rate.time_seconds;
        newExpiresAt = new Date(base + rate.time_seconds * 1000).toISOString();

        const { error } = await supabase
          .from('sessions')
          .update({
            time_remaining: newTimeRemaining,
            expires_at: newExpiresAt,
          })
          .eq('id', session.id);

        if (error) throw error;
        setSession({ ...session, time_remaining: newTimeRemaining, expires_at: newExpiresAt });
      } else {
        newTimeRemaining = rate.time_seconds;
        newExpiresAt = new Date(now + rate.time_seconds * 1000).toISOString();

        const { data, error } = await supabase
          .from('sessions')
          .insert({
            device_id: deviceId,
            time_remaining: newTimeRemaining,
            expires_at: newExpiresAt,
            is_active: true,
          })
          .select()
          .single();

        if (error) throw error;
        setSession(data);
      }

      setTimeRemaining(newTimeRemaining);

      await supabase.from('transactions').insert({
        type: 'coin',
        coin_value: rate.coin_value,
        time_seconds: rate.time_seconds,
        device_id: deviceId,
      });

      setMessage({ type: 'success', text: `Added ${formatTimeShort(rate.time_seconds)} of internet time!` });
      setSelectedRate(null);
    } catch {
      setMessage({ type: 'error', text: 'Failed to process coin. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleRedeemVoucher = async () => {
    if (!voucherCode.trim()) {
      setMessage({ type: 'error', text: 'Please enter a voucher code.' });
      return;
    }
    setLoading(true);
    setMessage(null);
    try {
      const { data: voucher, error: voucherErr } = await supabase
        .from('vouchers')
        .select('*')
        .eq('code', voucherCode.trim().toUpperCase())
        .eq('is_used', false)
        .maybeSingle();

      if (voucherErr || !voucher) {
        setMessage({ type: 'error', text: 'Invalid or already used voucher code.' });
        setLoading(false);
        return;
      }

      const now = Date.now();
      let newExpiresAt: string;
      let newTimeRemaining: number;

      if (session) {
        const currentExpiry = new Date(session.expires_at).getTime();
        const base = Math.max(currentExpiry, now);
        newTimeRemaining = Math.floor((base - now) / 1000) + voucher.time_seconds;
        newExpiresAt = new Date(base + voucher.time_seconds * 1000).toISOString();

        await supabase
          .from('sessions')
          .update({ time_remaining: newTimeRemaining, expires_at: newExpiresAt })
          .eq('id', session.id);
        setSession({ ...session, time_remaining: newTimeRemaining, expires_at: newExpiresAt });
      } else {
        newTimeRemaining = voucher.time_seconds;
        newExpiresAt = new Date(now + voucher.time_seconds * 1000).toISOString();

        const { data } = await supabase
          .from('sessions')
          .insert({ device_id: deviceId, time_remaining: newTimeRemaining, expires_at: newExpiresAt, is_active: true })
          .select()
          .single();
        if (data) setSession(data);
      }

      setTimeRemaining(newTimeRemaining);

      await supabase
        .from('vouchers')
        .update({ is_used: true, used_at: new Date().toISOString() })
        .eq('id', voucher.id);

      await supabase.from('transactions').insert({
        type: 'voucher',
        voucher_code: voucher.code,
        time_seconds: voucher.time_seconds,
        device_id: deviceId,
      });

      setMessage({ type: 'success', text: `Voucher redeemed! Added ${formatTimeShort(voucher.time_seconds)} of time.` });
      setVoucherCode('');
    } catch {
      setMessage({ type: 'error', text: 'Failed to redeem voucher. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const isConnected = timeRemaining > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex flex-col">
      {/* Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-blue-600/10" />
        <div className="relative px-6 py-8 md:py-12 text-center">
          <div className="inline-flex items-center gap-3 mb-3">
            <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/30">
              <Wifi className="w-7 h-7 md:w-8 md:h-8 text-white" />
            </div>
            <h1 className="text-2xl md:text-4xl font-bold text-white tracking-tight">{settings.name}</h1>
          </div>
          <p className="text-slate-400 text-sm md:text-base">{settings.subtitle}</p>
        </div>
      </header>

      {/* Status Bar */}
      <div className="px-4 md:px-6 mb-4">
        <div className={`max-w-2xl mx-auto rounded-2xl border p-4 md:p-5 transition-all duration-300 ${
          isConnected
            ? 'bg-emerald-500/10 border-emerald-500/30'
            : 'bg-slate-800/50 border-slate-700'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full transition-all ${
                isConnected ? 'bg-emerald-400 animate-pulse shadow-lg shadow-emerald-400/50' : 'bg-slate-600'
              }`} />
              <span className={`font-semibold text-sm md:text-base ${isConnected ? 'text-emerald-400' : 'text-slate-400'}`}>
                {isConnected ? 'Connected' : 'Not Connected'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className={`w-5 h-5 ${isConnected ? 'text-emerald-400' : 'text-slate-500'}`} />
              <span className={`font-mono text-xl md:text-2xl font-bold tabular-nums ${isConnected ? 'text-emerald-400' : 'text-slate-500'}`}>
                {formatTimeShort(timeRemaining)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 px-4 md:px-6 pb-8">
        <div className="max-w-2xl mx-auto space-y-4">
          {/* Coin Insertion */}
          <div className="bg-slate-800/60 backdrop-blur-sm rounded-2xl border border-slate-700 p-5 md:p-6">
            <div className="flex items-center gap-2 mb-4">
              <Coins className="w-5 h-5 text-cyan-400" />
              <h2 className="text-lg font-semibold text-white">Insert Coin</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {rates.length === 0 ? (
                <div className="col-span-full text-center py-8 text-slate-500 text-sm">
                  No rates configured. Please contact the administrator.
                </div>
              ) : (
                rates.map((rate) => (
                  <button
                    key={rate.id}
                    onClick={() => setSelectedRate(rate.coin_value)}
                    disabled={loading}
                    className={`group relative overflow-hidden rounded-xl border p-4 text-left transition-all duration-200 ${
                      selectedRate === rate.coin_value
                        ? 'border-cyan-400 bg-cyan-500/10'
                        : 'border-slate-700 bg-slate-800/80 hover:border-slate-600 hover:bg-slate-700/50'
                    } disabled:opacity-50`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-md">
                          <span className="text-xs font-bold text-amber-950">{rate.coin_value}</span>
                        </div>
                        <span className="text-white font-medium text-sm">
                          {rate.coin_value} {rate.coin_value === 1 ? 'Coin' : 'Coins'}
                        </span>
                      </div>
                      {selectedRate === rate.coin_value && <Check className="w-4 h-4 text-cyan-400" />}
                    </div>
                    <div className="flex items-center gap-1.5 text-cyan-400">
                      <Zap className="w-4 h-4" />
                      <span className="text-sm font-semibold">{rate.label || formatTimeShort(rate.time_seconds)}</span>
                    </div>
                  </button>
                ))
              )}
            </div>
            {selectedRate !== null && (
              <div className="mt-4">
                <button
                  onClick={() => {
                    const rate = rates.find((r) => r.coin_value === selectedRate);
                    if (rate) handleInsertCoin(rate);
                  }}
                  disabled={loading}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold text-sm shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Coins className="w-5 h-5" />}
                  {loading ? 'Processing...' : 'Insert Coin'}
                </button>
              </div>
            )}
          </div>

          {/* Voucher Redemption */}
          <div className="bg-slate-800/60 backdrop-blur-sm rounded-2xl border border-slate-700 p-5 md:p-6">
            <div className="flex items-center gap-2 mb-4">
              <Ticket className="w-5 h-5 text-purple-400" />
              <h2 className="text-lg font-semibold text-white">Redeem Voucher</h2>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={voucherCode}
                onChange={(e) => setVoucherCode(e.target.value.toUpperCase())}
                placeholder="Enter voucher code"
                disabled={loading}
                className="flex-1 px-4 py-3 rounded-xl bg-slate-900/80 border border-slate-700 text-white text-sm font-mono placeholder:text-slate-600 focus:outline-none focus:border-cyan-400 transition-colors"
              />
              <button
                onClick={handleRedeemVoucher}
                disabled={loading}
                className="px-5 py-3 rounded-xl bg-slate-700 text-white font-semibold text-sm hover:bg-slate-600 active:scale-95 transition-all disabled:opacity-50 flex items-center gap-2"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Redeem'}
              </button>
            </div>
          </div>

          {/* Message */}
          {message && (
            <div className={`rounded-xl border p-4 flex items-start gap-3 animate-in fade-in slide-in-from-bottom-2 duration-300 ${
              message.type === 'success'
                ? 'bg-emerald-500/10 border-emerald-500/30'
                : message.type === 'error'
                ? 'bg-red-500/10 border-red-500/30'
                : 'bg-blue-500/10 border-blue-500/30'
            }`}>
              {message.type === 'success' ? (
                <Check className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <Info className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
              )}
              <p className={`text-sm ${
                message.type === 'success' ? 'text-emerald-300' : 'text-red-300'
              }`}>
                {message.text}
              </p>
            </div>
          )}

          {/* Info Card */}
          <div className="bg-slate-800/40 rounded-2xl border border-slate-700/50 p-4">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
              <div className="text-xs text-slate-500 leading-relaxed">
                <p className="mb-1">Your internet time starts counting down immediately after insertion.</p>
                <p>Insert more coins or redeem a voucher to extend your time. Time stacks on top of your current session.</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="px-6 py-4 text-center">
        <p className="text-xs text-slate-600">
          {settings.name} &middot; Powered by VLY PisoWiFi
        </p>
      </footer>
    </div>
  );
}

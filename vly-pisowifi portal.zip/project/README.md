# VLY PisoWiFi - Raspberry Pi Hotspot Setup

This package contains everything you need to turn a Raspberry Pi into a coin-operated WiFi hotspot with a captive portal.

## What You Need

- Raspberry Pi (3B+, 4, or 5) with built-in WiFi
- Micro SD card (8GB minimum, 16GB recommended)
- Computer with an SD card reader
- Internet connection on the Pi (via Ethernet or temporary WiFi)

## Quick Setup (5 Steps)

### Step 1: Flash Raspberry Pi OS

1. Download [Raspberry Pi Imager](https://www.raspberrypi.com/software/) on your computer
2. Insert your SD card
3. Flash **Raspberry Pi OS (32-bit or 64-bit)** to the SD card
4. When the imager asks, click "Edit Settings" and:
   - Set a username and password (remember these!)
   - Check "Enable SSH"
5. Flash and wait for it to finish

### Step 2: Boot the Pi and Connect

1. Put the SD card in the Pi and power it on
2. Connect to the Pi via SSH from your computer:
   ```
   ssh your-username@raspberrypi.local
   ```
   (Or connect a keyboard and monitor directly)

### Step 3: Copy This Project to the Pi

**Option A: Using SCP (from your computer)**
```
scp -r . your-username@raspberrypi.local:~/vly-pisowifi
```

**Option B: Using a USB drive**
1. Copy this entire folder to a USB drive
2. Plug the USB drive into the Pi
3. Copy files: `cp -r /media/usb/* ~/vly-pisowifi/`

### Step 4: Run the Setup Script

On the Pi:
```
cd ~/vly-pisowifi
sudo bash setup-hotspot.sh
```

This will:
- Install all required software (hostapd, dnsmasq, nginx, Node.js)
- Set the Pi's WiFi IP to 10.0.0.1
- Create a WiFi hotspot named "VLY-PisoWiFi"
- Configure captive portal (all browser traffic redirects to the portal)
- Build and deploy the web portal

### Step 5: Reboot

```
sudo reboot
```

## How It Works

After reboot:
1. The Pi broadcasts a WiFi network called **VLY-PisoWiFi**
2. Anyone who connects (password: `vly12345`) and opens a browser
3. The browser is automatically redirected to **10.0.0.1**
4. The PisoWiFi portal appears — they insert coins or redeem vouchers
5. The admin can manage everything at `http://10.0.0.1/admin`

## Admin Access

1. Open `http://10.0.0.1/admin` in your browser
2. Click "Sign up" to create your admin account
3. Use the dashboard to:
   - Configure time rates (set hours, minutes, seconds per coin)
   - Generate voucher codes with custom time values
   - View transaction history
   - Customize the portal name

## Configuration

### Change WiFi Name and Password
```
sudo nano /etc/hostapd/hostapd.conf
```
Edit `ssid` (WiFi name) and `wpa_passphrase` (WiFi password), then:
```
sudo systemctl restart hostapd
```

### Change the Portal IP Address
```
sudo nano /etc/dhcpcd.conf
```
Change `10.0.0.1` to your preferred IP, then reboot.

### Internet Access for Connected Devices
If your Pi has Ethernet (eth0) connected to the internet, connected
devices will have internet access after their time is active.
The Pi acts as a router, forwarding traffic from WiFi to Ethernet.

## Troubleshooting

### Portal not showing when connecting
- Make sure you rebooted after setup
- Try navigating to `http://10.0.0.1` manually
- Check services: `sudo systemctl status hostapd dnsmasq nginx`

### WiFi network not visible
- Check hostapd: `sudo systemctl status hostapd`
- Check config: `sudo cat /etc/hostapd/hostapd.conf`
- Restart: `sudo systemctl restart hostapd`

### Cannot reach admin panel
- Go to `http://10.0.0.1/admin` in your browser
- Make sure you're connected to the VLY-PisoWiFi network

### Reset everything
```
sudo rm /etc/dhcpcd.conf.bak
sudo apt-get purge hostapd dnsmasq nginx -y
sudo reboot
```

## Files Included

| File | Purpose |
|------|---------|
| `setup-hotspot.sh` | Main setup script — run this on the Pi |
| `src/` | Portal and admin panel source code |
| `supabase/migrations/` | Database schema |
| `package.json` | Node.js dependencies |
| `README.md` | This file |

## Default Settings

| Setting | Value |
|---------|-------|
| WiFi Name (SSID) | VLY-PisoWiFi |
| WiFi Password | vly12345 |
| Portal IP | 10.0.0.1 |
| DHCP Range | 10.0.0.10 - 10.0.0.50 |
| WiFi Channel | 6 |

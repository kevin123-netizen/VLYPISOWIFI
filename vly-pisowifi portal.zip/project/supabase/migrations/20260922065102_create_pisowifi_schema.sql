/*
# VLY PisoWiFi - Database Schema

## Overview
Creates the full schema for a PisoWiFi (coin-operated WiFi hotspot) system:
- **rates**: coin-to-time conversion rates set by the admin
- **vouchers**: one-time-use codes that grant time
- **sessions**: active customer internet sessions with expiry timestamps
- **transactions**: audit log of every coin insertion and voucher redemption
- **admin_settings**: key-value store for admin config (portal name, etc.)

## Tables

### rates
- `id` (uuid, PK)
- `coin_value` (int) — number of coins this rate accepts (e.g. 1, 5, 10)
- `time_seconds` (int) — seconds of internet time granted
- `label` (text) — optional display label (e.g. "1 Hour")
- `is_active` (boolean, default true)
- `created_at` (timestamptz)

### vouchers
- `id` (uuid, PK)
- `code` (text, unique) — the redeemable code
- `time_seconds` (int) — seconds granted on redemption
- `is_used` (boolean, default false)
- `used_at` (timestamptz, nullable)
- `created_at` (timestamptz)

### sessions
- `id` (uuid, PK)
- `device_id` (text) — identifies the customer device (browser-generated)
- `time_remaining` (int) — seconds left
- `expires_at` (timestamptz) — when the session ends
- `is_active` (boolean, default true)
- `created_at` (timestamptz)

### transactions
- `id` (uuid, PK)
- `type` (text) — 'coin' or 'voucher'
- `coin_value` (int, nullable) — coins inserted (for coin type)
- `voucher_code` (text, nullable) — code redeemed (for voucher type)
- `time_seconds` (int) — seconds granted
- `device_id` (text, nullable) — device that made the transaction
- `created_at` (timestamptz)

### admin_settings
- `id` (uuid, PK)
- `key` (text, unique) — setting name
- `value` (text) — setting value
- `updated_at` (timestamptz)

## Security
- RLS enabled on all tables.
- This is a no-auth single-tenant app (admin uses Supabase Auth separately).
- All tables allow anon + authenticated CRUD since the portal is public-facing
  and the admin authenticates via Supabase Auth (authenticated role).
- Admin-only tables (rates, vouchers, admin_settings, transactions) restrict
  writes to authenticated users; reads are public for the portal to function.
*/

-- Rates table
CREATE TABLE IF NOT EXISTS rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  coin_value integer NOT NULL,
  time_seconds integer NOT NULL,
  label text DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE rates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_rates" ON rates;
CREATE POLICY "anon_read_rates" ON rates FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_rates" ON rates;
CREATE POLICY "auth_insert_rates" ON rates FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "auth_update_rates" ON rates;
CREATE POLICY "auth_update_rates" ON rates FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "auth_delete_rates" ON rates;
CREATE POLICY "auth_delete_rates" ON rates FOR DELETE
  TO authenticated USING (true);

-- Vouchers table
CREATE TABLE IF NOT EXISTS vouchers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  time_seconds integer NOT NULL,
  is_used boolean NOT NULL DEFAULT false,
  used_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE vouchers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_vouchers" ON vouchers;
CREATE POLICY "anon_read_vouchers" ON vouchers FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_vouchers" ON vouchers;
CREATE POLICY "auth_insert_vouchers" ON vouchers FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "auth_update_vouchers" ON vouchers;
CREATE POLICY "auth_update_vouchers" ON vouchers FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "auth_delete_vouchers" ON vouchers;
CREATE POLICY "auth_delete_vouchers" ON vouchers FOR DELETE
  TO authenticated USING (true);

-- Sessions table
CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text NOT NULL,
  time_remaining integer NOT NULL DEFAULT 0,
  expires_at timestamptz NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_sessions" ON sessions;
CREATE POLICY "anon_read_sessions" ON sessions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_sessions" ON sessions;
CREATE POLICY "anon_insert_sessions" ON sessions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_sessions" ON sessions;
CREATE POLICY "anon_update_sessions" ON sessions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_sessions" ON sessions;
CREATE POLICY "anon_delete_sessions" ON sessions FOR DELETE
  TO anon, authenticated USING (true);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL DEFAULT 'coin',
  coin_value integer,
  voucher_code text,
  time_seconds integer NOT NULL,
  device_id text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_transactions" ON transactions;
CREATE POLICY "anon_read_transactions" ON transactions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_transactions" ON transactions;
CREATE POLICY "auth_insert_transactions" ON transactions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "auth_update_transactions" ON transactions;
CREATE POLICY "auth_update_transactions" ON transactions FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "auth_delete_transactions" ON transactions;
CREATE POLICY "auth_delete_transactions" ON transactions FOR DELETE
  TO authenticated USING (true);

-- Admin settings table
CREATE TABLE IF NOT EXISTS admin_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text NOT NULL,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE admin_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_admin_settings" ON admin_settings;
CREATE POLICY "anon_read_admin_settings" ON admin_settings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_admin_settings" ON admin_settings;
CREATE POLICY "auth_insert_admin_settings" ON admin_settings FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "auth_update_admin_settings" ON admin_settings;
CREATE POLICY "auth_update_admin_settings" ON admin_settings FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "auth_delete_admin_settings" ON admin_settings;
CREATE POLICY "auth_delete_admin_settings" ON admin_settings FOR DELETE
  TO authenticated USING (true);

-- Seed default rate and settings
INSERT INTO rates (coin_value, time_seconds, label)
VALUES (1, 3600, '1 Hour')
ON CONFLICT DO NOTHING;

INSERT INTO admin_settings (key, value)
VALUES ('portal_name', 'VLY PisoWiFi')
ON CONFLICT (key) DO NOTHING;

INSERT INTO admin_settings (key, value)
VALUES ('portal_subtitle', 'Insert Coin to Start')
ON CONFLICT (key) DO NOTHING;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_vouchers_code ON vouchers(code);
CREATE INDEX IF NOT EXISTS idx_sessions_device ON sessions(device_id);
CREATE INDEX IF NOT EXISTS idx_transactions_created ON transactions(created_at DESC);

<?php
require_once __DIR__ . '/../../lib.php';
cors_headers();
require_admin_api();
if (!soft_rate_limit(get_api_key(), 'issue_prof')) json_out(['ok'=>false,'error'=>'rate_limited'],429);
$data = json_input();
$package = $data['package'] ?? '30D';
$days = isset($data['days']) ? intval($data['days']) : null;
$expires_at = $data['expires_at'] ?? ($days ? date('Y-m-d', strtotime("+{$days} days")) : date('Y-m-d', strtotime('+365 days')));
$notes = $data['notes'] ?? null;
$issued_by = $data['issued_by'] ?? 'admin';

$year = date('Y');
$code = sprintf('VLY-%s-%s-%s-%s', $year, strtoupper(substr(bin2hex(random_bytes(4)),0,4)), strtoupper(substr(bin2hex(random_bytes(4)),0,4)), strtoupper(substr(bin2hex(random_bytes(4)),0,4)) );
$payload = ['iss'=>PRODUCT_CODE,'type'=>'software','code'=>$code,'package'=>$package,'exp_date'=>$expires_at,'iat'=>time()];
$token = jwt_sign($payload);

$pdo = db();
$stmt = $pdo->prepare('INSERT INTO software_licenses (license_code, license_payload, package, expires_at, issued_by) VALUES (?,?,?,?,?)');
$stmt->execute([$code, $token, $package, $expires_at, $issued_by]);
$id = $pdo->lastInsertId();
audit('issue_software_license', ['id'=>$id,'code'=>$code,'package'=>$package,'expires_at'=>$expires_at,'issued_by'=>$issued_by]);
json_out(['ok'=>true,'id'=>$id,'license_code'=>$code,'token'=>$token]);
?>
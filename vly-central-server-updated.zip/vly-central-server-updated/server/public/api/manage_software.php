<?php
require_once __DIR__ . '/../../lib.php';
cors_headers();
require_admin_api();
$data = json_input();
$action = $data['action'] ?? '';
$pdo = db();
if ($action === 'revoke') {
  $id = intval($data['id'] ?? 0);
  $stmt = $pdo->prepare('UPDATE software_licenses SET revoked = 1 WHERE id = ?');
  $stmt->execute([$id]);
  audit('revoke_software_license', ['id'=>$id]);
  json_out(['ok'=>true]);
}
if ($action === 'unrevoke') {
  $id = intval($data['id'] ?? 0);
  $stmt = $pdo->prepare('UPDATE software_licenses SET revoked = 0 WHERE id = ?');
  $stmt->execute([$id]);
  audit('unrevoke_software_license', ['id'=>$id]);
  json_out(['ok'=>true]);
}
if ($action === 'bind') {
  $id = intval($data['id'] ?? 0);
  $device = trim($data['device_id'] ?? '');
  $stmt = $pdo->prepare('UPDATE software_licenses SET bound_device = ? WHERE id = ?');
  $stmt->execute([$device, $id]);
  audit('bind_software_license', ['id'=>$id,'device'=>$device]);
  json_out(['ok'=>true]);
}
if ($action === 'list') {
  $rows = $pdo->query('SELECT id, license_code, package, expires_at, bound_device, revoked, created_at FROM software_licenses ORDER BY id DESC LIMIT 1000')->fetchAll(PDO::FETCH_ASSOC);
  json_out(['ok'=>true,'licenses'=>$rows]);
}
json_out(['ok'=>false,'error'=>'unknown_action'],400); ?>
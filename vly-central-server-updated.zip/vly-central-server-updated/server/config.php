<?php
const DB_DRIVER = 'sqlite';
const SQLITE_PATH = __DIR__ . '/vly_central.sqlite';
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'admin123';
const ADMIN_API_TOKEN = 'CHANGE_ME_ADMIN_API_TOKEN_32CHARS';
const JWT_SECRET = 'CHANGE_ME_SUPER_SECRET_64CHARS';
const PRODUCT_CODE = 'VLY-PISOWIFI';
const TOKEN_TTL_HOURS = 24;
const CORS_ALLOWED_ORIGINS = ['*'];
const RL_BUCKET_SIZE = 300;
date_default_timezone_set('Asia/Manila');
?>